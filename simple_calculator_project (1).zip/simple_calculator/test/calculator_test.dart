import 'package:flutter_test/flutter_test.dart';
import 'package:simple_calculator/main.dart';

void main() {
  group('CalculatorController', () {
    CalculatorController makeCalculator() => CalculatorController();

    void pressAll(CalculatorController calculator, String keys) {
      for (final key in keys.split(' ')) {
        calculator.press(key);
      }
    }

    test('performs basic arithmetic', () {
      final calculator = makeCalculator();

      pressAll(calculator, '5 + 5 =');
      expect(calculator.displayValue, '10');

      pressAll(calculator, 'AC 20 − 7 =');
      expect(calculator.displayValue, '13');

      pressAll(calculator, 'AC 6 × 8 =');
      expect(calculator.displayValue, '48');

      pressAll(calculator, 'AC 100 ÷ 4 =');
      expect(calculator.displayValue, '25');
    });

    test('handles decimals without floating point artifacts', () {
      final calculator = makeCalculator();

      pressAll(calculator, '1 . 5 + 2 . 5 =');
      expect(calculator.displayValue, '4');

      pressAll(calculator, 'AC 0 . 0 0 1 + 0 . 5 =');
      expect(calculator.displayValue, '0.501');
    });

    test('uses natural percentage behavior', () {
      final calculator = makeCalculator();

      pressAll(calculator, '5 0 % =');
      expect(calculator.displayValue, '0.5');

      pressAll(calculator, 'AC 1 0 0 + 1 0 % =');
      expect(calculator.displayValue, '110');

      pressAll(calculator, 'AC 2 0 0 − 2 5 % =');
      expect(calculator.displayValue, '150');

      pressAll(calculator, 'AC 1 0 × 5 0 % =');
      expect(calculator.displayValue, '5');
    });

    test('supports continuous calculations', () {
      final calculator = makeCalculator();

      pressAll(calculator, '5 + 5 = × 2 = − 5 =');
      expect(calculator.displayValue, '15');
    });

    test('supports repeated operators by replacing the pending operator', () {
      final calculator = makeCalculator();

      pressAll(calculator, '5 + × 2 =');
      expect(calculator.displayValue, '10');
    });

    test('supports sign toggle, clear, and backspace', () {
      final calculator = makeCalculator();

      pressAll(calculator, '1 2 3 4 backspace');
      expect(calculator.displayValue, '123');
      pressAll(calculator, 'backspace backspace');
      expect(calculator.displayValue, '1');
      pressAll(calculator, 'backspace');
      expect(calculator.displayValue, '0');

      pressAll(calculator, '9 ±');
      expect(calculator.displayValue, '-9');
      pressAll(calculator, '±');
      expect(calculator.displayValue, '9');
      pressAll(calculator, 'AC');
      expect(calculator.displayValue, '0');
    });

    test('does not crash on division by zero', () {
      final calculator = makeCalculator();

      pressAll(calculator, '1 0 ÷ 0 =');
      expect(calculator.displayValue, "Can't divide by zero");
      expect(calculator.hasError, isTrue);
      calculator.press('AC');
      expect(calculator.displayValue, '0');
    });

    test('prevents multiple decimal points and unnecessary leading zeroes', () {
      final calculator = makeCalculator();

      pressAll(calculator, '0 . 5 . 2');
      expect(calculator.displayValue, '0.52');
      pressAll(calculator, 'AC 0 0 7');
      expect(calculator.displayValue, '7');
    });
  });
}
